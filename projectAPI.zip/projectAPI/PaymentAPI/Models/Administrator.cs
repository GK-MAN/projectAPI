﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace PaymentAPI.Models
{
	public class Administrator
	{
        //[Key]
        public int AdministratorId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string IdNumber { get; set; }
        public string PictureFileName { get; set; }
        public string ContactNumber { get; set; }
        public string WhatsApp { get; set; }
        public string IdFileName { get; set; }
        public  int PartnerId { get; set; }
        public int AdministratorTypeId { get; set; }
    }
    public class AdministratorPost
    {
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string IdNumber { get; set; }
        public string PictureFileName { get; set; }
        public string ContactNumber { get; set; }
        public string WhatsApp { get; set; }
        public string IdFileName { get; set; }
        public int PartnerId { get; set; }
        public int AdministratorTypeId { get; set; }
    }
}
