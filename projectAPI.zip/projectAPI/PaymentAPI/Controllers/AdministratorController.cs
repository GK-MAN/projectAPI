﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using PaymentAPI.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PaymentAPI.Controllers
{
	[Route("api/[controller]")]
	[ApiController]
	public class AdministratorController : ControllerBase
	{
		private readonly AdministratorContext _context;

		public AdministratorController(AdministratorContext context)
		{
			_context = context;
		}

		// GET: api/<AdministratorController>
		[HttpGet]
		public IEnumerable<string> Get()
		{
			return new string[] { "value1", "value2" };
		}

		// GET api/<AdministratorController>/5
		[HttpGet("{id}")]
		public string Get(int id)
		{
			return "value";
		}

		// POST: api/Administrator
		// To protect from overposting attacks, see https://go.microsoft.com/fwlink/?linkid=2123754
		[HttpPost]
		public async Task<ActionResult<Administrator>> PostAdministrator(Administrator administrator)
		{
			_context.Administrator.Add(administrator);
			await _context.SaveChangesAsync();

			return CreatedAtAction("Get", new { id = administrator.AdministratorId }, administrator);
		}

		// PUT api/<AdministratorController>/5
		[HttpPut("{id}")]
		public void Put(int id, [FromBody] string value)
		{
		}

		// DELETE api/<AdministratorController>/5
		[HttpDelete("{id}")]
		public void Delete(int id)
		{
		}
	}
}
